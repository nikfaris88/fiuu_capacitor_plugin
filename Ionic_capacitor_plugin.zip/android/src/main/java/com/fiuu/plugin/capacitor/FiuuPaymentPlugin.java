package com.fiuu.plugin.capacitor;

import android.app.Activity;
import android.content.Intent;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.molpay.molpayxdk.MOLPayActivity;
import com.molpay.molpayxdk.googlepay.ActivityGP;

import java.util.Calendar;
import java.util.HashMap;


@CapacitorPlugin(name = "FiuuPayment")
public class FiuuPaymentPlugin extends Plugin {

    @PluginMethod
    public void startPayment(PluginCall call, HashMap<String, Object> paymentDetails) {
        Activity activity = getActivity();

        if (activity == null) {
            call.reject("Activity is null");
            return;
        }


        try {
            // Start MOLPayActivity
            Intent intent;
            if (!paymentDetails.containsKey(MOLPayActivity.mp_channel)) {
                intent = new Intent(activity, ActivityGP.class);
            } else {
                intent = new Intent(activity, MOLPayActivity.class);
            }
            intent.putExtra(MOLPayActivity.MOLPayPaymentDetails, paymentDetails);
            startActivityForResult(call, intent, "handlePaymentResult");

        } catch (Exception e) {
            call.reject("Error in start payment: " + e.getMessage());
        }
    }

    @ActivityCallback
    private void handlePaymentResult(PluginCall call, Intent data) {
        if (data != null && data.hasExtra(MOLPayActivity.MOLPayTransactionResult)) {
            String transactionResult = data.getStringExtra(MOLPayActivity.MOLPayTransactionResult);
            JSObject result = new JSObject();
            result.put("result", transactionResult);
            call.resolve(result);
        } else {
            call.reject("Payment failed or was canceled");
        }
    }
}
