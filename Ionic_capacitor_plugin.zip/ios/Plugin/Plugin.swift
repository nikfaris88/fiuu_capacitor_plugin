import Foundation
import Capacitor
import FiuuPaymentSDK

@objc(FiuuPaymentPlugin)
public class FiuuPaymentPlugin: CAPPlugin {

    @objc func startMolpay(_ call: CAPPluginCall) {
        guard let paymentDetails = call.getString("paymentDetails") else {
            call.reject("Missing payment details")
            return
        }

        let molpay = MOLPayReactManagercd()  // Change this to the correct class from the SDK

        molpay.setPaymentDetails(paymentDetails) { paymentResult in
            let response = ["result": paymentResult]
            call.resolve(response)
        } errorCallback: { error in
            call.reject(error)
        }
    }
}
